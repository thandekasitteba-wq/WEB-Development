# HERRY'S EGGS 

## Project Overview
Website for Herry's Eggs, a local egg supplier in South Africa.

## Changelog - Part 1 Feedback Fixed
- Fixed CSS variable typo
- Consolidated 3 CSS files into single css/style.css
- Added alt text to all images
- Made navigation consistent

## Part 2 Implementation
- 2.2 Base: reset, :root variables, body styles
- 2.3 Typography: h1,h2,h3,p styling
- 2.4 Layout: Flex for header, Grid for container
- 2.5 Visual: colors, hover, buttons, cards
- 3.1 Responsive: @media 768px and 480px
- 3.2 Relative units: %, rem
- 3.3 Responsive images: max-width 100%

## Responsive Testing
- Desktop 1920px: 2 columns
- Tablet 768px: 1 column
- Mobile 375px: vertical nav

## References
[1] MDN Web Docs, "CSS," https://developer.mozilla.org/en-US/docs/Web/CSS
[2] W3Schools, "Responsive," https://www.w3schools.com/css/css_rwd_intro.asp
[3] Duckett J., HTML and CSS, Wiley, 2011.